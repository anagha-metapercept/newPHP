<?php
  require 'src/webscraper.php';
  $someParam = $argv[1];
  placeholder($someParam);
?>

<?php namespace Scrape;

  require '../vendor/autoload.php';
  use \DOMXPath;
  use \DOMDocument;
  use GuzzleHttp\Client;
  use GuzzleHttp\Exception\ConnectException;

  class Scrape
  {
    private $webClient;
    private $dom; 

    public function __construct($site, $timeout = 5.0)
    {
        $this->webClient = new Client([
                'base_uri' => $site,
                'timeout' => $timeout
            ]);
    }

     public function load($page) {
        try {
            $response = $this->webClient->get($page);
            } catch(ConnectException $e) {
                throw new \RuntimeException(
                  $e->getHandlerContext()['error']
                );
            }

        $html = $response->getBody();

        $this->dom = new DOMDocument;

        // Ignore errors caused by unsupported HTML5 tags
        libxml_use_internal_errors(true);
        $this->dom->loadHTML($html);
        libxml_clear_errors();

        return $this;
    }

     public function getNode($xpath, $parent=null) {
        $nodes = $this->getNodes($xpath, $parent);

        if ($nodes->length === 0) {
            throw new \RuntimeException("No matching node found");
        }

        return $nodes->item(0);
    }

   function getNodes($xpath, $parent=null) {
        $DomXpath = new DOMXPath($this->dom);
        $nodes = $DomXpath->query($xpath, $parent);
        return $nodes;
    }
  }


   /*function placeholder($someParam)
  {
    $client = new Client([
      'base_uri' => 'http://archive-grbj-2.s3-website-us-west-1.amazonaws.com/',
      'timeout'  => 5.0,
    ]);

    # Request / or root
    $response = $client->request('GET', '/');
    $body = $response->getBody();

    echo $someParam;
  }*/

?>

<?php
$scraper = new Scrape('http://archive-grbj-2.s3-website-us-west-1.amazonaws.com/');
$scraper->load('/');

//Article Title
$articleTitle = $scraper->getNode('//div[@class="record clearfix"]//h2//a');
echo $articleTitle->nodeValue;

//Article Url
$articleUrl = $scraper->getNode('//div[@class="abstract"]//a/@href');
echo $articleUrl->nodeValue;

//Article Date
$articleDate = $scraper->getNode('//div[@class="date"]');
echo $articleDate->nodeValue;

//Author Name
$authorName = $scraper->getNode('//div[@class="author"]');
echo $authorName->nodeValue;

//Author Url
$authorUrl = $scraper->getNode('//div[@class="author"]//a/@href');
echo $authorUrl->nodeValue;

/*$authorBio = $scraper->getNode('//div[@class="author_bio"]');
echo $authorBio->nodeValue;*/

?>